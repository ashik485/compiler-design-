#include <iostream>
#include <fstream>
using namespace std;

// Keyword check korar jonno alada function
bool isKeyword(string word)
{
    if (word == "int" || word == "float" || word == "double" ||
        word == "char" || word == "void" || word == "if" ||
        word == "else" || word == "for" || word == "while" ||
        word == "return")
        return true;
    else
        return false;
}

// Operator check korar jonno alada function
bool isOperator(string word)
{
    if (word == "+" || word == "-" || word == "*" || word == "/" ||
        word == "=" || word == "<<" || word == ">>" || word == "%" ||
        word == "<" || word == ">")
        return true;
    else
        return false;
}

// Punctuation check korar jonno alada function
bool isPunctuation(string word)
{
    if (word == ";" || word == "," || word == "(" || word == ")" ||
        word == "()" || word == "{" || word == "}" || word == "[" ||
        word == "]")
        return true;
    else
        return false;
}

bool isConstant(string word)
{
    if (word[0] >= '0' && word[0] <= '9')
        return true;
    else
        return false;
}

// Identifier check korar jonno
bool isIdentifier(string word)
{

    if ((word[0] >= 'a' && word[0] <= 'z') ||
        (word[0] >= 'A' && word[0] <= 'Z') ||
        word[0] == '_')
        return true;
    else
        return false;
}

void readFile()
{
    ifstream file("ashik.txt");
    ofstream out("output.txt");

    if (!file)
    {
        cout << "File not found" << endl;
        return;
    }

    string word;

    while (file >> word)
    {
        if (isKeyword(word))
        {
            cout << word << "  Keyword" << endl;
            out << word << "  Keyword" << endl;
        }
        else if (isOperator(word))
        {
            cout << word << "  Operator" << endl;
            out << word << "  Operator" << endl;
        }
        else if (isPunctuation(word))
        {
            cout << word << "  Punctuation" << endl;
            out << word << "  Punctuation" << endl;
        }
        else if (isConstant(word))
        {
            cout << word << "  Constant" << endl;
            out << word << "  Constant" << endl;
        }
        else if (word == "\"")
        {
            string str;
            getline(file, str, '"');
            cout << "\"" << str << "\"  String Constant" << endl;
            out << "\"" << str << "\"  String Constant" << endl;
        }
        else if (isIdentifier(word))
        {
            cout << word << "  Identifier" << endl;
            out << word << "  Identifier" << endl;
        }
        else
        {
            cout << word << "  Invalid Token" << endl;
            out << word << "  Invalid Token" << endl;
        }
    }

    file.close();
    out.close();
}

int main()
{
    readFile();
    return 0;
}
